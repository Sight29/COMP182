/*
Satbir dhaliwal
App: Set
*/
import java.util.TreeSet;
import java.util.Iterator;

public class Set<T extends Comparable<T>> implements Iterable<T>
{
   private TreeSet<T> set = new TreeSet<>();

   public void add(T input)
   {
      if (input == null)
      {
         throw new IllegalArgumentException("The inpute is null");
      }
      set.add(input);
   }

   public void remove(T input)
   {
      if (input == null)
      {
         throw new IllegalArgumentException("The input is null");
      }
      set.remove(input);
   }

   public boolean contains(T input)
   {
      if ( input == null)
      {
         throw new IllegalArgumentException("The input is null");
      }
      return set.contains(input);
   }

   public boolean isEmpty()
   {
      return set.isEmpty();
   }

   public int size()
   {
      return set.size();
   }

   public void clear()
   {
      set.clear();
   }

   public Iterator<T> iterator()
   {
      return set.iterator();
   }

}
